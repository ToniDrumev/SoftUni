from django.db import models


class BaseCharacter(models.Model):
	name = models.CharField(
		max_length=100,
	)

	description = models.TextField(
		max_length=200,
	)

	class Meta:
		abstract = True


class Mage(BaseCharacter):
	elemental_power = models.CharField(
		max_length=100,
	)

	spellbook_type = models.CharField(
		max_length=100,
	)


class Assassin(BaseCharacter):
	weapon_type = models.CharField(
		max_length=100,
	)

	assassination_technique = models.CharField(
		max_length=100,
	)


class DemonHunter(BaseCharacter):
	weapon_type = models.CharField(
		max_length=100,
	)

	demon_slaying_ability = models.CharField(
		max_length=100,
	)


class TimeMage(Mage):
	time_magic_mastery = models.CharField(
		max_length=100,
	)

	temporal_shift_ability = models.CharField(
		max_length=100,
	)


class Necromancer(Mage):
	raise_dead_ability = models.CharField(
		max_length=100,
	)


class ViperAssassin(Assassin):
	venomous_strikes_mastery = models.CharField(
		max_length=100,
	)

	venomous_bite_ability = models.CharField(
		max_length=100,
	)


class ShadowbladeAssassin(Assassin):
	shadowstep_ability = models.CharField(
		max_length=100,
	)


class VengeanceDemonHunter(DemonHunter):
	vengeance_mastery = models.CharField(
		max_length=100,
	)

	retribution_ability = models.CharField(
		max_length=100,
	)


class FelbladeDemonHunter(DemonHunter):
	felblade_ability = models.CharField(
		max_length=100,
	)
